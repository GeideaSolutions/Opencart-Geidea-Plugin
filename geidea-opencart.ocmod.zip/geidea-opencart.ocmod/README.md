# Opencart Geidea payment gateway module

## Installation

1 - download the folder and rename it to 'geidea-opencart.ocmod'

2 - Zip the folder

3 - Upload it as an extension
