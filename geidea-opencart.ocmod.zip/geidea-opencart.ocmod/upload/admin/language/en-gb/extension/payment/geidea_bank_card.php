<?php
// Heading
$_['heading_title'] = 'GeideaPay';

// Text
$_['text_geidea_bank_card'] = '<a target="_BLANK" href="https://geidea.net/egypt/en/"><img src="view/image/payment/logo.png" alt="Geidea Website" title="Geidea Website" style="border: 1px solid #EEEEEE;height:30px;" /></a>';
